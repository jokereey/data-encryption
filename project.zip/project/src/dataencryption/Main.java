package dataencryption;

import GUI.GUI;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        /*char w='w';
        System.out.println("w jako int:"+(int)w);
        String input = Main.inputFromUser();
        String encrypted = Main.encrypt(input);
        System.out.println(encrypted);
        String decrypted = Main.decrypt(encrypted);
        System.out.println(decrypted);
        */
        new GUI().setVisible(true);
        
        
    }

    

}
